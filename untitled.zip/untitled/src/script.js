function getDietRecommendation() {
  // Get values from the form elements
  var age = document.getElementById("age").value;
  var weight = document.getElementById("weight").value;
  var activity = document.getElementById("activity").value;
  var resultDiv = document.getElementById("resultDiv");

  // Validate the input
  if (!age || !weight) {
    resultDiv.innerHTML = "<p>Please enter all details!</p>";
    return;
  }

  // Calculate recommended calories based on activity level
  var calories;
  if (activity === "low") {
    calories = weight * 22;
  } else if (activity === "moderate") {
    calories = weight * 25;
  } else if (activity === "high") {
    calories = weight * 30;
  }

  // Define meal suggestions for different activity levels
  var meals = {
    low: ["Oatmeal", "Grilled Chicken Salad", "Brown Rice"],
    moderate: ["Whole Wheat Toast", "Salmon with Veggies", "Quinoa Salad"],
    high: ["Protein Shake", "Steak with Sweet Potatoes", "Pasta"]
  };

  // Update the resultDiv using a template literal with backticks
  var mealList = "<ul>";
for (var i = 0; i < meals[activity].length; i++) {
    mealList += "<li>" + meals[activity][i] + "</li>";
}
mealList += "</ul>";

resultDiv.innerHTML = 
    "<p>Recommended Daily Calories: <strong>" + calories + " kcal</strong></p>" +
    "<p>Suggested Meals:</p>" + mealList;
}

